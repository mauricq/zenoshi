<?php


namespace App\Entity;


abstract  class EntityProvider
{

}